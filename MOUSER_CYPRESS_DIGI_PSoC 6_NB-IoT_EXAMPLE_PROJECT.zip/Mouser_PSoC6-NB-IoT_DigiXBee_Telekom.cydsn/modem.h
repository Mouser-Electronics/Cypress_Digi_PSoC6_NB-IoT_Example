/******************************************************************************
* Project: Mouser_PSoC6-NB-IoT_DigiXBee_Telekom
* File   : modem.h
*
* Description: 
* Defines and funtion prototypes used for modem.c
*
******************************************************************************
*/
#ifndef MODEM_H
#define MODEM_H
    
    #include "project.h"

/*******************************************************************************
*        Defines
*******************************************************************************/
    
    // MQTTSN 

    #define MQTTSN_CLEANSESSION (0x04)

    #define MQTTSN_FLAG_RETAIN  (0x01)      // PUBLISH Retain flag

                                            // PUBLISH Quality of Service: 
    #define MQTTSN_FLAG_QOS0    (0x00)      // At most once delivery 
    #define MQTTSN_FLAG_QOS1    (0x02)      // At least once delivery 
    #define MQTTSN_FLAG_QOS2    (0x04)      // Exactly once delivery

    #define MQTTSN_FLAG_DUP     (0x08)      // Duplicate delivery of a PUBLISH Control Packet
                                            // The DUP flag MUST be set to 1 by the Client or Server when it attempts to re-deliver a PUBLISH Packet 
                                            // The DUP flag MUST be set to 0 for all QoS 0 messages

	#define MODEM_BUFFER_RX_MAX         (1024u)     // Ringbuffer size for receive information
    #define MODEM_BUFFER_RX_EOL_CNT     (0)         // 1: Count EOL character, 0: No EOL counter
    #define MODEM_BUFFER_RX_EOL         (0x0D)      // if enabled, define incoming character terminates line e.g. <CR\r> = 0x0D, <LF\n> = 0x0A
    #define MODEM_BUFFER_RX_ECHO        (0u)        // 1: Receive characters will be echoed
	#define MODEM_BUFFER_RX_ECHO_ADD_LF (0u)        // 1: Line-Feed (<LF>, 0x0A, 10d) will be added after Carriage Return (<CR>,0x0D,13d)
	#define MODEM_BUFFER_RX_SKIP_LF     (1u)        // 1: Received Line-Feed (<LF>, \n, 0x0a, 10d) will be skipped
	#define MODEM_BUFFER_RX_SKIP_CR     (0u)        // 1: Received Carriage-Return (<CR>, \r, 0x0d, 13d) will be skipped
	  
	#define MODEM_BUFFER_RX_ERROR_NO_ERROR   0u
	#define MODEM_BUFFER_RX_ERROR_OVERFLOW   1u


    // XBEE_EventHandler FSM states
    
    typedef enum {
        MODEM_STATE_IDLE = 0,
        MODEM_XBEE_AI,
        MODEM_XBEE_AI_WAIT,
        MODEM_XBEE_AI_DELAY,
        MODEM_STATE_MQTT_CONNECT,
        MODEM_STATE_MQTT_CONNECT_WAIT,
        MODEM_STATE_MQTT_REGISTER1,
        MODEM_STATE_MQTT_REGISTER1_WAIT,
        MODEM_STATE_MQTT_REGISTER2,
        MODEM_STATE_MQTT_REGISTER2_WAIT,
        MODEM_STATE_MQTT_REGISTER3,
        MODEM_STATE_MQTT_REGISTER3_WAIT,
        MODEM_STATE_MQTT_REGISTER4,
        MODEM_STATE_MQTT_REGISTER4_WAIT,
        MODEM_STATE_MQTT_PUBLISH1,
        MODEM_STATE_MQTT_PUBLISH1_WAIT,
        MODEM_STATE_MQTT_PUBLISH2,
        MODEM_STATE_MQTT_PUBLISH2_WAIT,
        MODEM_STATE_MQTT_PUBLISH3,
        MODEM_STATE_MQTT_PUBLISH3_WAIT,
        MODEM_STATE_MQTT_PUBLISH4,
        MODEM_STATE_MQTT_PUBLISH4_WAIT,
        MODEM_STATE_PUBLISHING,
        MODEM_STATE_ERROR
        } enModemState_t;
    
    typedef enum {
        MODEM_NBIOT_NOT_CONNECTED = 0,
        MODEM_NBIOT_CONNECTED,
        } enModemNbiotConnectState_t;
    
/*******************************************************************************
*        Functions
*******************************************************************************/
    
    void XBEE_EventHandler (void);                              // State machine for handling the modem
   	void MODEM_BUFFER_Init();                                   // Reception-Ring-Buffer gets initialized
    uint8_t MODEM_AddRxBuffer(uint8_t data);                    // Add received byte to reception-ring-buffer 
	uint8_t MODEM_BUFFER_RX_Get_Char();                         // Read a single byte from reception-buffer
	uint32_t MODEM_BUFFER_RX_Get_Count_Char();                  // Returns number of available bytes within reception ring buffer
    void MODEM_BUFFER_RX_Clr_Error();                           // Clear the RX buffer status
    uint8_t MODEM_BUFFER_RX_Get_Error();                        // Return of RX buffer status
    #if (MODEM_BUFFER_RX_EOL_CNT == 1)
	uint32_t MODEM_BUFFER_RX_Get_Count_Eol();                   // Returns number of EOL bytes within reception ring buffer
	void MODEM_Get_Line(char cDelimiter, char *pcOutput);       // Read one line out of RX buffer
    #endif
    uint16_t MODEM_Get_LineApi(char *pcOutput);                 // Get one received Digi XBee API line out of RX buffer
    enModemState_t MODEM_Get_State(void);                       // Return of MODEM state
    void MODEM_Set_State(enModemState_t newstate);              // Return status of network connection
    enModemNbiotConnectState_t MODEM_Get_NBIOT_Status();        // Return status of network connection
    void MQTTSN_Publish(uint16_t u16TopicId, uint16_t u16Value, uint8_t packetid); // Send a MQTT-SN PUBLISH command
    
#endif /* MODEM_H */   

/* [] END OF FILE */