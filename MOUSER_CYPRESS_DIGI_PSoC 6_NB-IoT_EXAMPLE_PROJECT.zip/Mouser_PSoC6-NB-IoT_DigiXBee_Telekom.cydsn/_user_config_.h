/******************************************************************************
* Project: Mouser_PSoC6-NB-IoT_DigiXBee_Telekom
* File   : _user_config_.h
*
* Description: 
* User defines to set correct hardware configuration and NB-IoT configuration
*
******************************************************************************
*/
#ifndef _USER_CONFIGURATION_H
#define _USER_CONFIGURATION_H
    
    #include "project.h"
      
    // Arduino RX/TX is shared with KitProg UART P5_0/P5_1
    // As Arduino RX/TX is used to control the external modem,
    // another SCB/UART needs to be connect to teh KiTProg USB2Serial bridge
    // if a user-terminal shall be used for HMI or output of debug information.
    //
    // Hardware modification (CYBLE-416045-EVAL):
    // - Remove R20 and R21 (= Disconnect KitProg from P5_0/P5_1)
    // - Wire from R20 e.g. to P9_0 (= connect KitProg TX)
    // - Wire from R21 e.g. to P9_1 (= connect KitProg RX)
    //
    // Hardware modification (CY8CKIT-062-BLE):
    // - Remove R119 and R120 (= Disconnect KitProg from P5_0/P5_1)
    // - Wire from R120 e.g. to P9_0 (= connect KitProg TX)
    // - Wire from R119 e.g. to P9_1 (= connect KitProg RX)

    #define KITPROG_UART_MAPPED_TO_NEW_SCB (0)  // <-- Set to '1' if your PSoC6 kit is modified 

    #define SIMULATION (0)                      // <-- Set to '1' if no external sensors (BME280, Light-Resistor) are connected

    #define AUTH_IMSI "123456789012345"         // <-- Add your IMSI here
    #define AUTH_PWD  "SRUkRd5H"                // <-- Add your Password here

    #define TOPIC1 "NBIoT/"AUTH_IMSI"/MES/1"
    #define TOPIC2 "NBIoT/"AUTH_IMSI"/MES/A"
    #define TOPIC3 "NBIoT/"AUTH_IMSI"/MES/5"
    #define TOPIC4 "NBIoT/"AUTH_IMSI"/MES/2"
    
    // On board LED polarity

    #define LED_ON  (0)
    #define LED_OFF (1)
    
// <-- End of User settings --> 
    
    #if (KITPROG_UART_MAPPED_TO_NEW_SCB == 1)
        
        #ifdef Uart_HMI_HW
            #define HMIUART    
        #else
            #error "Please enable Uart_HMI in TopDesign"
        #endif
        
    #else
        
        #ifdef Uart_HMI_HW
            #error "Please enable Uart_HMI in TopDesign"
        #endif
    #endif
            
#endif /* _USER_CONFIGURATION_H */   
/* [] END OF FILE */
