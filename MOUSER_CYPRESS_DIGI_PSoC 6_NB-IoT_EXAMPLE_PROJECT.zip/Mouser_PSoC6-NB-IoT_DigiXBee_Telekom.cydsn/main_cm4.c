/******************************************************************************
* Project: Mouser_PSoC6-NB-IoT_DigiXBee_Telekom
* File   : main_cm4.c
*
* Version: 1.0
*
* ------------------------------------------------------------------------------
* NOTE: 
* This project is for DEMONSTRATION PURPOSE only! 
* It shall not be used as is for any kind of comercial application!
* ------------------------------------------------------------------------------
*
* Description: 
* This example realizes a NB-IoT node accessing to Telekom Cloud-Of-Things
* by using Digi XB3-C-A2-UT-101
*
* Hardware Dependency: 
* Cypress CYBLE-416045-EVAL (Alternatively: CY8CKIT-062-BLE -> Change Pin Mapping)
* Digi    XB3-C-A2-UT-101 NB-IoT Modem
* BOSCH   BME280 Environmental sensor (connected via I2C)
* LDR     Light resistor
*
******************************************************************************
* Copyright (2018), Cypress Semiconductor Corporation.
******************************************************************************
* This software, including source code, documentation and related materials
* ("Software") is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and 
* foreign), United States copyright laws and international treaty provisions. 
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the 
* Cypress source code and derivative works for the sole purpose of creating 
* custom software in support of licensee product, such licensee product to be
* used only in conjunction with Cypress's integrated circuit as specified in the
* applicable agreement. Any reproduction, modification, translation, compilation,
* or representation of this Software except as specified above is prohibited 
* without the express written permission of Cypress.
* 
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, 
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes to the Software without notice. 
* Cypress does not assume any liability arising out of the application or use
* of Software or any product or circuit described in the Software. Cypress does
* not authorize its products for use as critical components in any products 
* where a malfunction or failure may reasonably be expected to result in 
* significant injury or death ("ACTIVE Risk Product"). By including Cypress's 
* product in a ACTIVE Risk Product, the manufacturer of such system or application
* assumes all risk of such use and in doing so indemnifies Cypress against all
* liability. Use of this Software may be limited by and subject to the applicable
* Cypress software license agreement.
*****************************************************************************/
#include "project.h"
#include "_user_config_.h"  // user configuration file
#include <stdio.h>          // e.g.: sprintf()
#include <string.h>         // e.g.: strcpy(), strlen(), strcmp()
#include <stdlib.h>         // e.g.: atoi()
#include "modem.h"          // includes all modem related variables, and functions

#include "sar/cy_sar.h"             // for usage of ADC
#include "sysanalog/cy_sysanalog.h" // for usage of ADC

#include "BME280_driver-master\bme280.h"    // provided by Bosch
                                            // https://www.bosch-sensortec.com/bst/products/all_products/bme280
                                            //-> BME280 driver

#if defined (__GNUC__)
    /* Add an explicit reference to the floating point printf library */
    /* to allow usage of the floating point conversion specifiers. */
    /* This is not linked in by default with the newlib-nano library. */
    asm (".global _printf_float");
#endif
                                            
/*******************************************************************************
*        Global Defines
*******************************************************************************/
// see _user_config_.h
        
/*******************************************************************************
*        Global variables
*******************************************************************************/

char acPrintfBuffer[128];                   // used for sprintf

// See modem.c

extern uint16_t u16TopicId1;                // keep ID of Topic 1 Temp
extern uint16_t u16TopicId2;                // keep ID of Topic 2 Pressure
extern uint16_t u16TopicId3;                // keep ID of Topic 3 Humidity
extern uint16_t u16TopicId4;                // keep ID of Topic 4 Light

// UART Modem

uint32_t u32ModemStatus;
uint8_t  u8ModemReadData;
uint8_t  u8SystemError;

// Application

uint16_t u16SensorValue1;
uint16_t u16SensorValue2;
uint16_t u16SensorValue3;
uint16_t u16SensorValue4;

unsigned int u32PublishLoopCounter;
uint32_t u32PublishDelay;

/*******************************************************************************
* Sensor BME280
********************************************************************************
* BOSCH BME280 API routines 
* see https://www.bosch-sensortec.com/bst/products/all_products/bme280 
* -> BME280 driver) 
*******************************************************************************/

struct bme280_dev dev;
struct bme280_data comp_data;
int8_t rslt = BME280_OK;
uint8_t settings_sel;

/* Implement ISR for I2C_1 */
void I2C_1_Isr(void)
{
    Cy_SCB_I2C_Interrupt(I2C_HW, &I2C_context);
}

void user_delay_ms(uint32_t period)
{
    /*
     * Return control or wait, for a period amount of milliseconds
     */
    CyDelay(period);
}

int8_t user_i2c_read(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len)
{
    int8_t rslt = 0; /* Return 0 for Success, non-zero for failure */
    uint8_t u8data, u8loop;

    /*
     * The parameter dev_id can be used as a variable to store the I2C address of the device
     */

    /*
     * Data on the bus should be like
     * |------------+---------------------|
     * | I2C action | Data                |
     * |------------+---------------------|
     * | Start      | -                   |
     * | Write      | (reg_addr)          |
     * | Stop       | -                   |
     * | Start      | -                   |
     * | Read       | (reg_data[0])       |
     * | Read       | (....)              |
     * | Read       | (reg_data[len - 1]) |
     * | Stop       | -                   |
     * |------------+---------------------|
     */

    Cy_SCB_I2C_MasterSendStart(I2C_HW, dev_id, 0, 200, &I2C_context);
    Cy_SCB_I2C_MasterWriteByte(I2C_HW, reg_addr, 200, &I2C_context);
    Cy_SCB_I2C_MasterSendReStart(I2C_HW, dev_id, 1, 200, &I2C_context);
    
    for (u8loop=2; u8loop<=len; u8loop++)
    {
        Cy_SCB_I2C_MasterReadByte(I2C_HW, CY_SCB_I2C_ACK, &u8data, 200, &I2C_context);    
        *reg_data++ = u8data;
    }

    Cy_SCB_I2C_MasterReadByte(I2C_HW, CY_SCB_I2C_NAK, &u8data, 200, &I2C_context);    
    *reg_data++ = u8data;
    Cy_SCB_I2C_MasterSendStop(I2C_HW, 200, &I2C_context); 
    return rslt;
}

int8_t user_i2c_write(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len)
{
    int8_t rslt = 0; /* Return 0 for Success, non-zero for failure */
    uint8_t u8data, u8loop;

    /*
     * The parameter dev_id can be used as a variable to store the I2C address of the device
     */

    /*
     * Data on the bus should be like
     * |------------+---------------------|
     * | I2C action | Data                |
     * |------------+---------------------|
     * | Start      | -                   |
     * | Write      | (reg_addr)          |
     * | Write      | (reg_data[0])       |
     * | Write      | (....)              |
     * | Write      | (reg_data[len - 1]) |
     * | Stop       | -                   |
     * |------------+---------------------|
     */

    Cy_SCB_I2C_MasterSendStart(I2C_HW, dev_id, 0, 200, &I2C_context);
    Cy_SCB_I2C_MasterWriteByte(I2C_HW, reg_addr, 200, &I2C_context);
     
    for (u8loop=1; u8loop<=len; u8loop++)
    {
        u8data = *reg_data++;
        Cy_SCB_I2C_MasterWriteByte(I2C_HW, u8data, 200, &I2C_context); 
    }
    
    Cy_SCB_I2C_MasterSendStop(I2C_HW, 200, &I2C_context);  
    return rslt;
}


/*******************************************************************************
*        Interrupt Service Routines
*******************************************************************************/

/*******************************************************************************
* Function Name: Isr_SysTick
********************************************************************************
* Summary:
* Used as 100ms Interval-Timer  
*******************************************************************************/
void Isr_SysTick(void)
{
    //Cy_GPIO_Inv(Testpin_PORT, Testpin_NUM);    // Test only
    
    XBEE_EventHandler();
    
    if (u32PublishDelay)
    {
        u32PublishDelay = u32PublishDelay - 1 ;
    }
}

/*******************************************************************************
* Function Name: Isr_MODEM
********************************************************************************
* Summary:
* Each incoming modem data will be catched by the interrupt 
* and routed to a ring-buffer.
*******************************************************************************/
void Isr_MODEM(void)
{
    uint32_t u32char;
    
    Cy_GPIO_Inv(LED_Blue_PORT, LED_Blue_NUM);
    
    // Check for "RX fifo not empty interrupt"
    if((Uart_Modem_HW->INTR_RX_MASKED & SCB_INTR_RX_MASKED_NOT_EMPTY_Msk ) != 0)
	{
        u32char = (char)Cy_SCB_UART_Get(Uart_Modem_HW); // receive data
        MODEM_AddRxBuffer(u32char);

        // Clear UART "RX fifo not empty interrupt"
		Uart_Modem_HW->INTR_RX = Uart_Modem_HW->INTR_RX & SCB_INTR_RX_NOT_EMPTY_Msk;        
	}   
}

/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Description:
*
* - Peripheral initialization
* - Waiting for modem connection to network
* - Initiation of connecting to Telekom Cloud-Of-Things, and topig registering
* - Regular publishing of sensor values (= MQTT-SN topics)
*
* @param       none
* @return      none
*
*******************************************************************************/

int main()
{
    __enable_irq(); //!<  Enable global interrupts.
    
    // GPIO: Switch Red LED on while initialization
    
    Cy_GPIO_Write(LED_Red_PORT, LED_Red_NUM, LED_ON);     
    Cy_GPIO_Write(LED_Green_PORT, LED_Green_NUM, LED_ON); 
    Cy_GPIO_Write(LED_Blue_PORT, LED_Blue_NUM, LED_ON);   
    
    #ifdef HMIUART
        //Debug UART (Requires Hardware modification, see above)
        Cy_SCB_UART_Init(Uart_HMI_HW, &Uart_HMI_config, &Uart_HMI_context);
        Cy_SCB_UART_Enable(Uart_HMI_HW); // Activate UART
        Cy_SCB_UART_PutString(Uart_HMI_HW, "\r\rCypress PSoC 6 MCU & Telekom Cloud-Of-Things Demonstrator using Digi Module (Version 2018-11-08)\r\r");
    #endif
    
    // Modem UART
    
    MODEM_BUFFER_Init();

    Cy_SCB_UART_Init(Uart_Modem_HW, &Uart_Modem_config, &Uart_Modem_context);
    Cy_SCB_UART_Enable(Uart_Modem_HW); // Activate MODEM
    
    Uart_Modem_HW->INTR_RX_MASK = SCB_INTR_RX_MASK_NOT_EMPTY_Msk;            // Unmasking only the RX fifo not empty interrupt bit
    Cy_SysInt_Init(&Uart_Modem_SCB_IRQ_cfg, &Isr_MODEM);                     // MODEM interrupt configuration
    NVIC_EnableIRQ((IRQn_Type) Uart_Modem_SCB_IRQ_cfg.intrSrc);              // Register MODEM interrupt in NVIC

    // ADC
    
    ADC_Start();

    // I2C 
    
    /* Initialize and enable the I2C in master mode */ 
    if (Cy_SCB_I2C_Init(I2C_HW, &I2C_config, &I2C_context) != CY_SCB_I2C_SUCCESS)
    {
        #ifdef HMIUART
            Cy_SCB_UART_PutString(Uart_HMI_HW, "*** I2C initialization error -> STOP ***\r");
        #endif
        while (1)
        {
            Cy_GPIO_Inv(LED_Red_PORT, LED_Red_NUM); // Toggle LED, indicate Error
            CyDelay(333);
        }
    }
    
    Cy_SCB_I2C_SetDataRate(I2C_HW, I2C_DATA_RATE_HZ, I2C_CLK_FREQ_HZ);  // Configure desired data rate
    Cy_SysInt_Init(&I2C_SCB_IRQ_cfg, &I2C_Interrupt);                   // Hook interrupt service routine
    NVIC_EnableIRQ((IRQn_Type) I2C_SCB_IRQ_cfg.intrSrc);                // Enable interrupt in NVIC
    Cy_SCB_I2C_Enable(I2C_HW);                                          // Enable I2C master hardware
    
    // BME280 interface over I2C
    
    dev.dev_id = BME280_I2C_ADDR_PRIM;
    dev.intf = BME280_I2C_INTF;
    dev.read = user_i2c_read;
    dev.write = user_i2c_write;
    dev.delay_ms = user_delay_ms;

    rslt = bme280_init(&dev);

    if (rslt == BME280_OK)
    {
        #ifdef HMIUART
            sprintf(acPrintfBuffer, "BME280 initialization done\r");
            Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
        #endif
    }
    else
    {
        #ifdef HMIUART
            sprintf(acPrintfBuffer, "BME280 initialization failed (0x%02x) -> STOP\r",rslt);
            Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);   
        #endif
        while (1)
        {
            Cy_GPIO_Inv(LED_Red_PORT, LED_Red_NUM); // Toggle LED, indicate Error
            CyDelay(666);
        }
    }
    
    /* Recommended mode of operation */
    dev.settings.osr_h = BME280_OVERSAMPLING_1X;
    dev.settings.osr_p = BME280_OVERSAMPLING_16X;
    dev.settings.osr_t = BME280_OVERSAMPLING_2X;
    dev.settings.filter = BME280_FILTER_COEFF_16;
    settings_sel = BME280_OSR_PRESS_SEL | BME280_OSR_TEMP_SEL | BME280_OSR_HUM_SEL | BME280_FILTER_SEL;
    rslt = bme280_set_sensor_settings(settings_sel, &dev);
    
    // SysTick -> will generate 100ms Interrupts
    
    Cy_SysTick_Init(CY_SYSTICK_CLOCK_SOURCE_CLK_CPU, 10000000);	// ticks(24bit) -> dT=ticks/clock
    Cy_SysTick_SetCallback(0, Isr_SysTick); 

    // Application Start

    Cy_GPIO_Write(LED_Red_PORT, LED_Red_NUM, LED_OFF);      // LED Red  off
    Cy_GPIO_Write(LED_Blue_PORT, LED_Blue_NUM, LED_ON);     // LED Blue on
    
    // Wait until Modem is connected to network
    
    MODEM_Set_State(MODEM_XBEE_AI);
    while (MODEM_Get_State() != MODEM_STATE_PUBLISHING)
    {
        // wait until AI shows connection to network   
        Cy_GPIO_Inv(LED_Blue_PORT, LED_Blue_NUM);           // LED Blue blinking
        CyDelay(500);
    }

    Cy_GPIO_Write(LED_Blue_PORT, LED_Blue_NUM, LED_OFF);    // LED Blue  off

    // Connect to Telekom Cloud-Of-Things (CoT)

    #ifdef HMIUART
        Cy_SCB_UART_PutString(Uart_HMI_HW, "\r\r*** Ready for publishing -> Entering MAIN LOOP\r");
    #endif
    
    u32PublishLoopCounter   = 0; // Incremented by each Publish cycle (just for information)
    u32PublishDelay         = 0; // Publish immeadiately after connection to CoT
    
    #if (SIMULATION == 1)
        u16SensorValue1 = 15;  // Initial value for simulation of Temp
        u16SensorValue2 = 995; // Initial value for simulation of Pressure
        u16SensorValue3 = 40;  // Initial value for simulation of Humidity
        u16SensorValue4 = 0;   // Initial value for simulation of Light
    #endif
    
    for(;;)
    {
        if (MODEM_Get_State() == MODEM_STATE_PUBLISHING)
        {
                if (u32PublishDelay == 0)
                {
                    #ifdef HMIUART
                        sprintf(acPrintfBuffer, "\r\r--- NEW PUBLISH [%08x, %d] ---", u32PublishLoopCounter, u32PublishLoopCounter);
                        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                    #endif

                    
                    #if (SIMULATION == 1)

                        // Simulation values
                           
                        u16SensorValue1 = u16SensorValue1 + 2;
                        if (u16SensorValue1 > 30)
                        {
                            u16SensorValue1 = 15;
                        }
                        
                        u16SensorValue2 = u16SensorValue2 + 1;
                        if (u16SensorValue2 > 1010)
                        {
                            u16SensorValue2 = 995;
                        }

                        u16SensorValue3 = u16SensorValue3 + 5;
                        if (u16SensorValue3 > 80)
                        {
                            u16SensorValue3 = 40;
                        }

                        u16SensorValue4 = u16SensorValue4 + 50;
                        if (u16SensorValue4 >= 5000)
                        {
                            u16SensorValue4 = 0;
                        }
                    
                    #else
                        
                        // Get BME280 Sensor value
                        
                        rslt = bme280_set_sensor_mode(BME280_FORCED_MODE, &dev);
                        dev.delay_ms(40); // Wait for the measurement to complete and print data @25Hz
                        rslt = bme280_get_sensor_data(BME280_ALL, &comp_data, &dev);

                        u16SensorValue1 = comp_data.temperature / 100;  //  2581 -> 25 Grad
                        u16SensorValue2 = comp_data.pressure  / 100;    // 99390 -> 993hPa
                        u16SensorValue3 = comp_data.humidity / 1000;    // 51509 -> 51%

                        // Get Light sensor value

                        ADC_StartConvert(); 
                        ADC_IsEndConversion(CY_SAR_WAIT_FOR_RESULT);
                        u16SensorValue4 = ADC_CountsTo_mVolts(0, ADC_GetResult32(0));

                    #endif   

                    #ifdef HMIUART
                        sprintf(acPrintfBuffer, "\rTemperature: %d %cC, Pressure: %d hPa, Humidity: %d %%, Light: %d mV\r",u16SensorValue1, 176, u16SensorValue2, u16SensorValue3, u16SensorValue4);
                        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                    #endif
                    
                    // Publish Topic 1
                    
                    #ifdef HMIUART
                        sprintf(acPrintfBuffer, "\rPC ->: Publish Topic 1 (%04X) / Value: (%3d)", u16TopicId1, u16SensorValue1);
                        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                    #endif
                    
                    MQTTSN_Publish(u16TopicId1, u16SensorValue1, 0);
                    
                    // Publish Topic 2
                    
                    #ifdef HMIUART
                        sprintf(acPrintfBuffer, "\rPC ->: Publish Topic 2 (%04X) / Value: (%3d)", u16TopicId2, u16SensorValue2);
                        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                    #endif
                    
                    MQTTSN_Publish(u16TopicId2, u16SensorValue2, 0);

                    // Publish Topic 3
                    
                    #ifdef HMIUART
                        sprintf(acPrintfBuffer, "\rPC ->: Publish Topic 3 (%04X) / Value: (%3d)", u16TopicId3, u16SensorValue3);
                        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                    #endif
                    
                    MQTTSN_Publish(u16TopicId3, u16SensorValue3, 0);

                    // Publish Topic 4
                    
                    #ifdef HMIUART
                        sprintf(acPrintfBuffer, "\rPC ->: Publish Topic 4 (%04X) / Value: (%3d)", u16TopicId4, u16SensorValue4);
                        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                    #endif
                    
                    MQTTSN_Publish(u16TopicId4, u16SensorValue4, 0);

                    // Publishing done! ... Reset timer for next publish
                    u32PublishLoopCounter = u32PublishLoopCounter + 1;
                    u32PublishDelay = 600; // e.g 600*100ms = 1 Minute
                }
            }
                
            // Has the connection to CoT been disconnected?
            
            if (MODEM_NBIOT_NOT_CONNECTED == MODEM_Get_NBIOT_Status())
            {
                MODEM_Set_State(MODEM_STATE_MQTT_CONNECT);
            }
 
    } // for(;;)
} // main()

/* [] END OF FILE */
