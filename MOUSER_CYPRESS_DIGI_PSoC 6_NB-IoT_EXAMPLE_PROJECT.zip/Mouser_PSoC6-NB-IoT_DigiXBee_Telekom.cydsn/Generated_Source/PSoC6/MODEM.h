/***************************************************************************//**
* \file MODEM.h
* \version 2.0
*
*  This file provides constants and parameter values for the UART component.
*
********************************************************************************
* \copyright
* Copyright 2016-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(MODEM_CY_SCB_UART_PDL_H)
#define MODEM_CY_SCB_UART_PDL_H

#include "cyfitter.h"
#include "scb/cy_scb_uart.h"

#if defined(__cplusplus)
extern "C" {
#endif

/***************************************
*   Initial Parameter Constants
****************************************/

#define MODEM_DIRECTION  (3U)
#define MODEM_ENABLE_RTS (0U)
#define MODEM_ENABLE_CTS (0U)

/* UART direction enum */
#define MODEM_RX    (0x1U)
#define MODEM_TX    (0x2U)

#define MODEM_ENABLE_RX  (0UL != (MODEM_DIRECTION & MODEM_RX))
#define MODEM_ENABLE_TX  (0UL != (MODEM_DIRECTION & MODEM_TX))


/***************************************
*        Function Prototypes
***************************************/
/**
* \addtogroup group_general
* @{
*/
/* Component specific functions. */
void MODEM_Start(void);

/* Basic functions */
__STATIC_INLINE cy_en_scb_uart_status_t MODEM_Init(cy_stc_scb_uart_config_t const *config);
__STATIC_INLINE void MODEM_DeInit(void);
__STATIC_INLINE void MODEM_Enable(void);
__STATIC_INLINE void MODEM_Disable(void);

/* Register callback. */
__STATIC_INLINE void MODEM_RegisterCallback(cy_cb_scb_uart_handle_events_t callback);

/* Configuration change. */
#if (MODEM_ENABLE_CTS)
__STATIC_INLINE void MODEM_EnableCts(void);
__STATIC_INLINE void MODEM_DisableCts(void);
#endif /* (MODEM_ENABLE_CTS) */

#if (MODEM_ENABLE_RTS)
__STATIC_INLINE void     MODEM_SetRtsFifoLevel(uint32_t level);
__STATIC_INLINE uint32_t MODEM_GetRtsFifoLevel(void);
#endif /* (MODEM_ENABLE_RTS) */

__STATIC_INLINE void MODEM_EnableSkipStart(void);
__STATIC_INLINE void MODEM_DisableSkipStart(void);

#if (MODEM_ENABLE_RX)
/* Low level: Receive direction. */
__STATIC_INLINE uint32_t MODEM_Get(void);
__STATIC_INLINE uint32_t MODEM_GetArray(void *buffer, uint32_t size);
__STATIC_INLINE void     MODEM_GetArrayBlocking(void *buffer, uint32_t size);
__STATIC_INLINE uint32_t MODEM_GetRxFifoStatus(void);
__STATIC_INLINE void     MODEM_ClearRxFifoStatus(uint32_t clearMask);
__STATIC_INLINE uint32_t MODEM_GetNumInRxFifo(void);
__STATIC_INLINE void     MODEM_ClearRxFifo(void);
#endif /* (MODEM_ENABLE_RX) */

#if (MODEM_ENABLE_TX)
/* Low level: Transmit direction. */
__STATIC_INLINE uint32_t MODEM_Put(uint32_t data);
__STATIC_INLINE uint32_t MODEM_PutArray(void *buffer, uint32_t size);
__STATIC_INLINE void     MODEM_PutArrayBlocking(void *buffer, uint32_t size);
__STATIC_INLINE void     MODEM_PutString(char_t const string[]);
__STATIC_INLINE void     MODEM_SendBreakBlocking(uint32_t breakWidth);
__STATIC_INLINE uint32_t MODEM_GetTxFifoStatus(void);
__STATIC_INLINE void     MODEM_ClearTxFifoStatus(uint32_t clearMask);
__STATIC_INLINE uint32_t MODEM_GetNumInTxFifo(void);
__STATIC_INLINE bool     MODEM_IsTxComplete(void);
__STATIC_INLINE void     MODEM_ClearTxFifo(void);
#endif /* (MODEM_ENABLE_TX) */

#if (MODEM_ENABLE_RX)
/* High level: Ring buffer functions. */
__STATIC_INLINE void     MODEM_StartRingBuffer(void *buffer, uint32_t size);
__STATIC_INLINE void     MODEM_StopRingBuffer(void);
__STATIC_INLINE void     MODEM_ClearRingBuffer(void);
__STATIC_INLINE uint32_t MODEM_GetNumInRingBuffer(void);

/* High level: Receive direction functions. */
__STATIC_INLINE cy_en_scb_uart_status_t MODEM_Receive(void *buffer, uint32_t size);
__STATIC_INLINE void     MODEM_AbortReceive(void);
__STATIC_INLINE uint32_t MODEM_GetReceiveStatus(void);
__STATIC_INLINE uint32_t MODEM_GetNumReceived(void);
#endif /* (MODEM_ENABLE_RX) */

#if (MODEM_ENABLE_TX)
/* High level: Transmit direction functions. */
__STATIC_INLINE cy_en_scb_uart_status_t MODEM_Transmit(void *buffer, uint32_t size);
__STATIC_INLINE void     MODEM_AbortTransmit(void);
__STATIC_INLINE uint32_t MODEM_GetTransmitStatus(void);
__STATIC_INLINE uint32_t MODEM_GetNumLeftToTransmit(void);
#endif /* (MODEM_ENABLE_TX) */

/* Interrupt handler */
__STATIC_INLINE void MODEM_Interrupt(void);
/** @} group_general */


/***************************************
*    Variables with External Linkage
***************************************/
/**
* \addtogroup group_globals
* @{
*/
extern uint8_t MODEM_initVar;
extern cy_stc_scb_uart_config_t const MODEM_config;
extern cy_stc_scb_uart_context_t MODEM_context;
/** @} group_globals */


/***************************************
*         Preprocessor Macros
***************************************/
/**
* \addtogroup group_macros
* @{
*/
/** The pointer to the base address of the hardware */
#define MODEM_HW     ((CySCB_Type *) MODEM_SCB__HW)
/** @} group_macros */


/***************************************
*    In-line Function Implementation
***************************************/

/*******************************************************************************
* Function Name: MODEM_Init
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Init() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t MODEM_Init(cy_stc_scb_uart_config_t const *config)
{
   return Cy_SCB_UART_Init(MODEM_HW, config, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_DeInit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DeInit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_DeInit(void)
{
    Cy_SCB_UART_DeInit(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_Enable
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Enable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_Enable(void)
{
    Cy_SCB_UART_Enable(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_Disable
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Disable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_Disable(void)
{
    Cy_SCB_UART_Disable(MODEM_HW, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_RegisterCallback
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_RegisterCallback() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_RegisterCallback(cy_cb_scb_uart_handle_events_t callback)
{
    Cy_SCB_UART_RegisterCallback(MODEM_HW, callback, &MODEM_context);
}


#if (MODEM_ENABLE_CTS)
/*******************************************************************************
* Function Name: MODEM_EnableCts
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_EnableCts() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_EnableCts(void)
{
    Cy_SCB_UART_EnableCts(MODEM_HW);
}


/*******************************************************************************
* Function Name: Cy_SCB_UART_DisableCts
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DisableCts() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_DisableCts(void)
{
    Cy_SCB_UART_DisableCts(MODEM_HW);
}
#endif /* (MODEM_ENABLE_CTS) */


#if (MODEM_ENABLE_RTS)
/*******************************************************************************
* Function Name: MODEM_SetRtsFifoLevel
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_SetRtsFifoLevel() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_SetRtsFifoLevel(uint32_t level)
{
    Cy_SCB_UART_SetRtsFifoLevel(MODEM_HW, level);
}


/*******************************************************************************
* Function Name: MODEM_GetRtsFifoLevel
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetRtsFifoLevel() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetRtsFifoLevel(void)
{
    return Cy_SCB_UART_GetRtsFifoLevel(MODEM_HW);
}
#endif /* (MODEM_ENABLE_RTS) */


/*******************************************************************************
* Function Name: MODEM_EnableSkipStart
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_EnableSkipStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_EnableSkipStart(void)
{
    Cy_SCB_UART_EnableSkipStart(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_DisableSkipStart
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DisableSkipStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_DisableSkipStart(void)
{
    Cy_SCB_UART_DisableSkipStart(MODEM_HW);
}


#if (MODEM_ENABLE_RX)
/*******************************************************************************
* Function Name: MODEM_Get
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Get() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_Get(void)
{
    return Cy_SCB_UART_Get(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_GetArray
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetArray() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetArray(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_GetArray(MODEM_HW, buffer, size);
}


/*******************************************************************************
* Function Name: MODEM_GetArrayBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetArrayBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_GetArrayBlocking(void *buffer, uint32_t size)
{
    Cy_SCB_UART_GetArrayBlocking(MODEM_HW, buffer, size);
}


/*******************************************************************************
* Function Name: MODEM_GetRxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetRxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetRxFifoStatus(void)
{
    return Cy_SCB_UART_GetRxFifoStatus(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_ClearRxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_ClearRxFifoStatus(uint32_t clearMask)
{
    Cy_SCB_UART_ClearRxFifoStatus(MODEM_HW, clearMask);
}


/*******************************************************************************
* Function Name: MODEM_GetNumInRxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInRxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetNumInRxFifo(void)
{
    return Cy_SCB_UART_GetNumInRxFifo(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_ClearRxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_ClearRxFifo(void)
{
    Cy_SCB_UART_ClearRxFifo(MODEM_HW);
}
#endif /* (MODEM_ENABLE_RX) */


#if (MODEM_ENABLE_TX)
/*******************************************************************************
* Function Name: MODEM_Put
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Put() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_Put(uint32_t data)
{
    return Cy_SCB_UART_Put(MODEM_HW,data);
}


/*******************************************************************************
* Function Name: MODEM_PutArray
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutArray() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_PutArray(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_PutArray(MODEM_HW, buffer, size);
}


/*******************************************************************************
* Function Name: MODEM_PutArrayBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutArrayBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_PutArrayBlocking(void *buffer, uint32_t size)
{
    Cy_SCB_UART_PutArrayBlocking(MODEM_HW, buffer, size);
}


/*******************************************************************************
* Function Name: MODEM_PutString
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutString() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_PutString(char_t const string[])
{
    Cy_SCB_UART_PutString(MODEM_HW, string);
}


/*******************************************************************************
* Function Name: MODEM_SendBreakBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_SendBreakBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_SendBreakBlocking(uint32_t breakWidth)
{
    Cy_SCB_UART_SendBreakBlocking(MODEM_HW, breakWidth);
}


/*******************************************************************************
* Function Name: MODEM_GetTxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetTxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetTxFifoStatus(void)
{
    return Cy_SCB_UART_GetTxFifoStatus(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_ClearTxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearTxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_ClearTxFifoStatus(uint32_t clearMask)
{
    Cy_SCB_UART_ClearTxFifoStatus(MODEM_HW, clearMask);
}


/*******************************************************************************
* Function Name: MODEM_GetNumInTxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInTxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetNumInTxFifo(void)
{
    return Cy_SCB_UART_GetNumInTxFifo(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_IsTxComplete
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_IsTxComplete() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE bool MODEM_IsTxComplete(void)
{
    return Cy_SCB_UART_IsTxComplete(MODEM_HW);
}


/*******************************************************************************
* Function Name: MODEM_ClearTxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearTxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_ClearTxFifo(void)
{
    Cy_SCB_UART_ClearTxFifo(MODEM_HW);
}
#endif /* (MODEM_ENABLE_TX) */


#if (MODEM_ENABLE_RX)
/*******************************************************************************
* Function Name: MODEM_StartRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_StartRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_StartRingBuffer(void *buffer, uint32_t size)
{
    Cy_SCB_UART_StartRingBuffer(MODEM_HW, buffer, size, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_StopRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_StopRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_StopRingBuffer(void)
{
    Cy_SCB_UART_StopRingBuffer(MODEM_HW, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_ClearRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_ClearRingBuffer(void)
{
    Cy_SCB_UART_ClearRingBuffer(MODEM_HW, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_GetNumInRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetNumInRingBuffer(void)
{
    return Cy_SCB_UART_GetNumInRingBuffer(MODEM_HW, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_Receive
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Receive() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t MODEM_Receive(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_Receive(MODEM_HW, buffer, size, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_GetReceiveStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetReceiveStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetReceiveStatus(void)
{
    return Cy_SCB_UART_GetReceiveStatus(MODEM_HW, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_AbortReceive
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_AbortReceive() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_AbortReceive(void)
{
    Cy_SCB_UART_AbortReceive(MODEM_HW, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_GetNumReceived
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumReceived() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetNumReceived(void)
{
    return Cy_SCB_UART_GetNumReceived(MODEM_HW, &MODEM_context);
}
#endif /* (MODEM_ENABLE_RX) */


#if (MODEM_ENABLE_TX)
/*******************************************************************************
* Function Name: MODEM_Transmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Transmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t MODEM_Transmit(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_Transmit(MODEM_HW, buffer, size, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_GetTransmitStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetTransmitStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetTransmitStatus(void)
{
    return Cy_SCB_UART_GetTransmitStatus(MODEM_HW, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_AbortTransmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_AbortTransmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_AbortTransmit(void)
{
    Cy_SCB_UART_AbortTransmit(MODEM_HW, &MODEM_context);
}


/*******************************************************************************
* Function Name: MODEM_GetNumLeftToTransmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumLeftToTransmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t MODEM_GetNumLeftToTransmit(void)
{
    return Cy_SCB_UART_GetNumLeftToTransmit(MODEM_HW, &MODEM_context);
}
#endif /* (MODEM_ENABLE_TX) */


/*******************************************************************************
* Function Name: MODEM_Interrupt
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Interrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void MODEM_Interrupt(void)
{
    Cy_SCB_UART_Interrupt(MODEM_HW, &MODEM_context);
}

#if defined(__cplusplus)
}
#endif

#endif /* MODEM_CY_SCB_UART_PDL_H */


/* [] END OF FILE */
