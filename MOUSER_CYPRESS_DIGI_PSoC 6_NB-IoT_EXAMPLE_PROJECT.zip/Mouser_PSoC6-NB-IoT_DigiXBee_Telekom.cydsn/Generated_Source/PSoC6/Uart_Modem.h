/***************************************************************************//**
* \file Uart_Modem.h
* \version 2.0
*
*  This file provides constants and parameter values for the UART component.
*
********************************************************************************
* \copyright
* Copyright 2016-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(Uart_Modem_CY_SCB_UART_PDL_H)
#define Uart_Modem_CY_SCB_UART_PDL_H

#include "cyfitter.h"
#include "scb/cy_scb_uart.h"

#if defined(__cplusplus)
extern "C" {
#endif

/***************************************
*   Initial Parameter Constants
****************************************/

#define Uart_Modem_DIRECTION  (3U)
#define Uart_Modem_ENABLE_RTS (0U)
#define Uart_Modem_ENABLE_CTS (0U)

/* UART direction enum */
#define Uart_Modem_RX    (0x1U)
#define Uart_Modem_TX    (0x2U)

#define Uart_Modem_ENABLE_RX  (0UL != (Uart_Modem_DIRECTION & Uart_Modem_RX))
#define Uart_Modem_ENABLE_TX  (0UL != (Uart_Modem_DIRECTION & Uart_Modem_TX))


/***************************************
*        Function Prototypes
***************************************/
/**
* \addtogroup group_general
* @{
*/
/* Component specific functions. */
void Uart_Modem_Start(void);

/* Basic functions */
__STATIC_INLINE cy_en_scb_uart_status_t Uart_Modem_Init(cy_stc_scb_uart_config_t const *config);
__STATIC_INLINE void Uart_Modem_DeInit(void);
__STATIC_INLINE void Uart_Modem_Enable(void);
__STATIC_INLINE void Uart_Modem_Disable(void);

/* Register callback. */
__STATIC_INLINE void Uart_Modem_RegisterCallback(cy_cb_scb_uart_handle_events_t callback);

/* Configuration change. */
#if (Uart_Modem_ENABLE_CTS)
__STATIC_INLINE void Uart_Modem_EnableCts(void);
__STATIC_INLINE void Uart_Modem_DisableCts(void);
#endif /* (Uart_Modem_ENABLE_CTS) */

#if (Uart_Modem_ENABLE_RTS)
__STATIC_INLINE void     Uart_Modem_SetRtsFifoLevel(uint32_t level);
__STATIC_INLINE uint32_t Uart_Modem_GetRtsFifoLevel(void);
#endif /* (Uart_Modem_ENABLE_RTS) */

__STATIC_INLINE void Uart_Modem_EnableSkipStart(void);
__STATIC_INLINE void Uart_Modem_DisableSkipStart(void);

#if (Uart_Modem_ENABLE_RX)
/* Low level: Receive direction. */
__STATIC_INLINE uint32_t Uart_Modem_Get(void);
__STATIC_INLINE uint32_t Uart_Modem_GetArray(void *buffer, uint32_t size);
__STATIC_INLINE void     Uart_Modem_GetArrayBlocking(void *buffer, uint32_t size);
__STATIC_INLINE uint32_t Uart_Modem_GetRxFifoStatus(void);
__STATIC_INLINE void     Uart_Modem_ClearRxFifoStatus(uint32_t clearMask);
__STATIC_INLINE uint32_t Uart_Modem_GetNumInRxFifo(void);
__STATIC_INLINE void     Uart_Modem_ClearRxFifo(void);
#endif /* (Uart_Modem_ENABLE_RX) */

#if (Uart_Modem_ENABLE_TX)
/* Low level: Transmit direction. */
__STATIC_INLINE uint32_t Uart_Modem_Put(uint32_t data);
__STATIC_INLINE uint32_t Uart_Modem_PutArray(void *buffer, uint32_t size);
__STATIC_INLINE void     Uart_Modem_PutArrayBlocking(void *buffer, uint32_t size);
__STATIC_INLINE void     Uart_Modem_PutString(char_t const string[]);
__STATIC_INLINE void     Uart_Modem_SendBreakBlocking(uint32_t breakWidth);
__STATIC_INLINE uint32_t Uart_Modem_GetTxFifoStatus(void);
__STATIC_INLINE void     Uart_Modem_ClearTxFifoStatus(uint32_t clearMask);
__STATIC_INLINE uint32_t Uart_Modem_GetNumInTxFifo(void);
__STATIC_INLINE bool     Uart_Modem_IsTxComplete(void);
__STATIC_INLINE void     Uart_Modem_ClearTxFifo(void);
#endif /* (Uart_Modem_ENABLE_TX) */

#if (Uart_Modem_ENABLE_RX)
/* High level: Ring buffer functions. */
__STATIC_INLINE void     Uart_Modem_StartRingBuffer(void *buffer, uint32_t size);
__STATIC_INLINE void     Uart_Modem_StopRingBuffer(void);
__STATIC_INLINE void     Uart_Modem_ClearRingBuffer(void);
__STATIC_INLINE uint32_t Uart_Modem_GetNumInRingBuffer(void);

/* High level: Receive direction functions. */
__STATIC_INLINE cy_en_scb_uart_status_t Uart_Modem_Receive(void *buffer, uint32_t size);
__STATIC_INLINE void     Uart_Modem_AbortReceive(void);
__STATIC_INLINE uint32_t Uart_Modem_GetReceiveStatus(void);
__STATIC_INLINE uint32_t Uart_Modem_GetNumReceived(void);
#endif /* (Uart_Modem_ENABLE_RX) */

#if (Uart_Modem_ENABLE_TX)
/* High level: Transmit direction functions. */
__STATIC_INLINE cy_en_scb_uart_status_t Uart_Modem_Transmit(void *buffer, uint32_t size);
__STATIC_INLINE void     Uart_Modem_AbortTransmit(void);
__STATIC_INLINE uint32_t Uart_Modem_GetTransmitStatus(void);
__STATIC_INLINE uint32_t Uart_Modem_GetNumLeftToTransmit(void);
#endif /* (Uart_Modem_ENABLE_TX) */

/* Interrupt handler */
__STATIC_INLINE void Uart_Modem_Interrupt(void);
/** @} group_general */


/***************************************
*    Variables with External Linkage
***************************************/
/**
* \addtogroup group_globals
* @{
*/
extern uint8_t Uart_Modem_initVar;
extern cy_stc_scb_uart_config_t const Uart_Modem_config;
extern cy_stc_scb_uart_context_t Uart_Modem_context;
/** @} group_globals */


/***************************************
*         Preprocessor Macros
***************************************/
/**
* \addtogroup group_macros
* @{
*/
/** The pointer to the base address of the hardware */
#define Uart_Modem_HW     ((CySCB_Type *) Uart_Modem_SCB__HW)
/** @} group_macros */


/***************************************
*    In-line Function Implementation
***************************************/

/*******************************************************************************
* Function Name: Uart_Modem_Init
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Init() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t Uart_Modem_Init(cy_stc_scb_uart_config_t const *config)
{
   return Cy_SCB_UART_Init(Uart_Modem_HW, config, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_DeInit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DeInit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_DeInit(void)
{
    Cy_SCB_UART_DeInit(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_Enable
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Enable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_Enable(void)
{
    Cy_SCB_UART_Enable(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_Disable
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Disable() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_Disable(void)
{
    Cy_SCB_UART_Disable(Uart_Modem_HW, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_RegisterCallback
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_RegisterCallback() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_RegisterCallback(cy_cb_scb_uart_handle_events_t callback)
{
    Cy_SCB_UART_RegisterCallback(Uart_Modem_HW, callback, &Uart_Modem_context);
}


#if (Uart_Modem_ENABLE_CTS)
/*******************************************************************************
* Function Name: Uart_Modem_EnableCts
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_EnableCts() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_EnableCts(void)
{
    Cy_SCB_UART_EnableCts(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Cy_SCB_UART_DisableCts
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DisableCts() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_DisableCts(void)
{
    Cy_SCB_UART_DisableCts(Uart_Modem_HW);
}
#endif /* (Uart_Modem_ENABLE_CTS) */


#if (Uart_Modem_ENABLE_RTS)
/*******************************************************************************
* Function Name: Uart_Modem_SetRtsFifoLevel
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_SetRtsFifoLevel() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_SetRtsFifoLevel(uint32_t level)
{
    Cy_SCB_UART_SetRtsFifoLevel(Uart_Modem_HW, level);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetRtsFifoLevel
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetRtsFifoLevel() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetRtsFifoLevel(void)
{
    return Cy_SCB_UART_GetRtsFifoLevel(Uart_Modem_HW);
}
#endif /* (Uart_Modem_ENABLE_RTS) */


/*******************************************************************************
* Function Name: Uart_Modem_EnableSkipStart
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_EnableSkipStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_EnableSkipStart(void)
{
    Cy_SCB_UART_EnableSkipStart(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_DisableSkipStart
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_DisableSkipStart() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_DisableSkipStart(void)
{
    Cy_SCB_UART_DisableSkipStart(Uart_Modem_HW);
}


#if (Uart_Modem_ENABLE_RX)
/*******************************************************************************
* Function Name: Uart_Modem_Get
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Get() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_Get(void)
{
    return Cy_SCB_UART_Get(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetArray
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetArray() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetArray(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_GetArray(Uart_Modem_HW, buffer, size);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetArrayBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetArrayBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_GetArrayBlocking(void *buffer, uint32_t size)
{
    Cy_SCB_UART_GetArrayBlocking(Uart_Modem_HW, buffer, size);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetRxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetRxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetRxFifoStatus(void)
{
    return Cy_SCB_UART_GetRxFifoStatus(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_ClearRxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_ClearRxFifoStatus(uint32_t clearMask)
{
    Cy_SCB_UART_ClearRxFifoStatus(Uart_Modem_HW, clearMask);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetNumInRxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInRxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetNumInRxFifo(void)
{
    return Cy_SCB_UART_GetNumInRxFifo(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_ClearRxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_ClearRxFifo(void)
{
    Cy_SCB_UART_ClearRxFifo(Uart_Modem_HW);
}
#endif /* (Uart_Modem_ENABLE_RX) */


#if (Uart_Modem_ENABLE_TX)
/*******************************************************************************
* Function Name: Uart_Modem_Put
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Put() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_Put(uint32_t data)
{
    return Cy_SCB_UART_Put(Uart_Modem_HW,data);
}


/*******************************************************************************
* Function Name: Uart_Modem_PutArray
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutArray() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_PutArray(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_PutArray(Uart_Modem_HW, buffer, size);
}


/*******************************************************************************
* Function Name: Uart_Modem_PutArrayBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutArrayBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_PutArrayBlocking(void *buffer, uint32_t size)
{
    Cy_SCB_UART_PutArrayBlocking(Uart_Modem_HW, buffer, size);
}


/*******************************************************************************
* Function Name: Uart_Modem_PutString
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_PutString() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_PutString(char_t const string[])
{
    Cy_SCB_UART_PutString(Uart_Modem_HW, string);
}


/*******************************************************************************
* Function Name: Uart_Modem_SendBreakBlocking
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_SendBreakBlocking() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_SendBreakBlocking(uint32_t breakWidth)
{
    Cy_SCB_UART_SendBreakBlocking(Uart_Modem_HW, breakWidth);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetTxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetTxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetTxFifoStatus(void)
{
    return Cy_SCB_UART_GetTxFifoStatus(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_ClearTxFifoStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearTxFifoStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_ClearTxFifoStatus(uint32_t clearMask)
{
    Cy_SCB_UART_ClearTxFifoStatus(Uart_Modem_HW, clearMask);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetNumInTxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInTxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetNumInTxFifo(void)
{
    return Cy_SCB_UART_GetNumInTxFifo(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_IsTxComplete
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_IsTxComplete() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE bool Uart_Modem_IsTxComplete(void)
{
    return Cy_SCB_UART_IsTxComplete(Uart_Modem_HW);
}


/*******************************************************************************
* Function Name: Uart_Modem_ClearTxFifo
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearTxFifo() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_ClearTxFifo(void)
{
    Cy_SCB_UART_ClearTxFifo(Uart_Modem_HW);
}
#endif /* (Uart_Modem_ENABLE_TX) */


#if (Uart_Modem_ENABLE_RX)
/*******************************************************************************
* Function Name: Uart_Modem_StartRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_StartRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_StartRingBuffer(void *buffer, uint32_t size)
{
    Cy_SCB_UART_StartRingBuffer(Uart_Modem_HW, buffer, size, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_StopRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_StopRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_StopRingBuffer(void)
{
    Cy_SCB_UART_StopRingBuffer(Uart_Modem_HW, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_ClearRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_ClearRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_ClearRingBuffer(void)
{
    Cy_SCB_UART_ClearRingBuffer(Uart_Modem_HW, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetNumInRingBuffer
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumInRingBuffer() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetNumInRingBuffer(void)
{
    return Cy_SCB_UART_GetNumInRingBuffer(Uart_Modem_HW, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_Receive
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Receive() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t Uart_Modem_Receive(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_Receive(Uart_Modem_HW, buffer, size, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetReceiveStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetReceiveStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetReceiveStatus(void)
{
    return Cy_SCB_UART_GetReceiveStatus(Uart_Modem_HW, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_AbortReceive
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_AbortReceive() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_AbortReceive(void)
{
    Cy_SCB_UART_AbortReceive(Uart_Modem_HW, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetNumReceived
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumReceived() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetNumReceived(void)
{
    return Cy_SCB_UART_GetNumReceived(Uart_Modem_HW, &Uart_Modem_context);
}
#endif /* (Uart_Modem_ENABLE_RX) */


#if (Uart_Modem_ENABLE_TX)
/*******************************************************************************
* Function Name: Uart_Modem_Transmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Transmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE cy_en_scb_uart_status_t Uart_Modem_Transmit(void *buffer, uint32_t size)
{
    return Cy_SCB_UART_Transmit(Uart_Modem_HW, buffer, size, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetTransmitStatus
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetTransmitStatus() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetTransmitStatus(void)
{
    return Cy_SCB_UART_GetTransmitStatus(Uart_Modem_HW, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_AbortTransmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_AbortTransmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_AbortTransmit(void)
{
    Cy_SCB_UART_AbortTransmit(Uart_Modem_HW, &Uart_Modem_context);
}


/*******************************************************************************
* Function Name: Uart_Modem_GetNumLeftToTransmit
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_GetNumLeftToTransmit() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE uint32_t Uart_Modem_GetNumLeftToTransmit(void)
{
    return Cy_SCB_UART_GetNumLeftToTransmit(Uart_Modem_HW, &Uart_Modem_context);
}
#endif /* (Uart_Modem_ENABLE_TX) */


/*******************************************************************************
* Function Name: Uart_Modem_Interrupt
****************************************************************************//**
*
* Invokes the Cy_SCB_UART_Interrupt() PDL driver function.
*
*******************************************************************************/
__STATIC_INLINE void Uart_Modem_Interrupt(void)
{
    Cy_SCB_UART_Interrupt(Uart_Modem_HW, &Uart_Modem_context);
}

#if defined(__cplusplus)
}
#endif

#endif /* Uart_Modem_CY_SCB_UART_PDL_H */


/* [] END OF FILE */
