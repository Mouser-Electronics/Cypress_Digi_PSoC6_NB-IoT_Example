/******************************************************************************
* Project: Mouser_PSoC6-NB-IoT_DigiXBee_Telekom
* File   : modem.c
*
* Description: 
* Receive-Ring-Buffer and Modem related functions including state machine
*
******************************************************************************
*/
#include "modem.h"
#include "project.h"
#include "_user_config_.h"  // user configuration file
#include <string.h>         // e.g.: strcpy(), strlen(), strcmp()
#include <stdio.h>          // e.g.: sprintf()
#include <stdlib.h>         // e.g.: atoi()

#ifdef HMIUART
  extern char acPrintfBuffer[];            // used for sprintf
#endif

enModemState_t enModemState;

enModemNbiotConnectState_t u32XbeeNbiotConnect;

uint16_t u16TopicId;                // ID returned by Cloud
uint16_t u16TopicId1;               // keep ID of Topic 1 Temp
uint16_t u16TopicId2;               // keep ID of Topic 2 Pressure
uint16_t u16TopicId3;               // keep ID of Topic 3 Humidity
uint16_t u16TopicId4;               // keep ID of Topic 4 Light
char acMqttsnBufferIn[32];
char acXbeeApiBufferIn[32];

uint32_t u32XbeeTransmitStatus;
//0x0 	Successful transmit
//0x21 	Failure to transmit to cell network
//0x22 	Not registered to cell network
//0x2c 	Invalid frame values (check the phone number)
//0x31 	Internal error
//0x32 	Resource error (retry operation later)
//0x74 	Message too long
//0x78 	Invalid UDP port
//0x79 	Invalid TCP port
//0x7A 	Invalid host address
//0x7B 	Invalid data mode
//0x80 	Connection refused
//0x81 	Socket connection lost
//0x82 	No server
//0x83 	Socket closed
//0x84 	Unknown server
//0x85 	Unknown error
//0x86 	Invalid TLS configuration (missing file, and so forth)

uint32_t u32XbeeModemStatus = 0xff; 
//0 = Hardware reset or power up 
//1 = Watchdog timer reset 
//2 = Registered with cellular network 
//3 = Unregistered with cellular network
//0x0E = Remote Manager connected
//0x0F = Remote Manager disconnected
//0x34 = Bandmask configuration failed
//0xFF = no information yet received from modem

uint32_t u32XbeeResponseAi;
//0x00	Connected to the Internet.
//0x22	Registering to cellular network.
//0x23	Connecting to the Internet.
//0x24	The cellular component is missing, corrupt, or otherwise in error. 
//The cellular component requires a new firmware image.
//0x25	Cellular network registration denied.
//0x2A	Airplane mode.
//0x2B	USB Direct active.
//0x2C	Cellular component is in PSM. Note For NB-IoT, TCP support is dependent on the network. Contact your network provider for details.
//0x2F	Bypass mode active.
//0xFF	Initializing.


uint32_t u32ModemTimeout;

//volatile uint8_t MODEM_State;
//volatile uint8_t MODEM_Error;


//char MODEM_RX_LINE[MODEM_BUFFER_RX_LINE]; // Keeps on received line

uint8_t  MODEM_BUFFER_RX[MODEM_BUFFER_RX_MAX];
uint16_t MODEM_BUFFER_RX_Read_Ptr;
uint16_t MODEM_BUFFER_RX_Write_Ptr;
uint16_t MODEM_BUFFER_RX_Counter; // available characters in buffer  
uint8_t  MODEM_BUFFER_RX_Error;
uint8_t  MODEM_BUFFER_RX_Cnt_Eol;       // Line counter
uint8_t  MODEM_Rx_Evaluate_Flag; // 1: command line ready for evaluation
 

/**
 ******************************************************************************
 ** \brief Reception-Ring-Buffer gets initialized
 **
 ** This function resets the pointer to the Reception- and Transmission buffer.
 ** 
 ** \param none
 **
 ** \retval none
 **
 ******************************************************************************/
void MODEM_BUFFER_Init()
{
  MODEM_BUFFER_RX_Read_Ptr  = 0;
  MODEM_BUFFER_RX_Write_Ptr = 0;
  MODEM_BUFFER_RX_Counter   = 0;
  MODEM_BUFFER_RX_Error     = MODEM_BUFFER_RX_ERROR_NO_ERROR;
  MODEM_BUFFER_RX_Cnt_Eol   = 0;
  enModemState              = MODEM_STATE_IDLE;  
}

/**
 ******************************************************************************
 ** \brief Add received byte to reception-ring-buffer
 **
 ** This function adds a received byte to the reception ring buffer,
 ** and updates status values accordingly:
 **     MODEM_Rx_Cnt_Eol (if applicable)
 **     MODEM_BUFFER_RX_Error
 ** 
 ** \pre MODEM_BUFFER_Init() must be called first to initial the buffer
 ** \pre This function is called by the service of the related uart receive interrupt
 **
 ** \param [in]  u8Data         Receive character
 **
 ** \retval u8Data              Added data is returned
 **
 ******************************************************************************/
uint8_t    MODEM_AddRxBuffer(uint8_t u8Data)
{
    __disable_irq(); 
    #if MODEM_BUFFER_RX_ECHO == 1
    MODEM_BUFFER_TX_Add_Char(u8Data);
    
    #if MODEM_BUFFER_RX_ECHO_ADD_LF == 1
    if (u8Data == 13)
    {
      MODEM_BUFFER_TX_Add_Char(0x0A);
    }
    #endif
    #endif
  
    switch (u8Data)
    {
        #if (MODEM_BUFFER_RX_SKIP_LF == 1)
        case 10 : // Linefeed
            break;
            #endif
              
        #if (MODEM_BUFFER_RX_SKIP_CR == 1)
        case 13 : // Linefeed
            break;
            #endif
        
        default :
        
        #if (MODEM_BUFFER_RX_EOL_CNT == 1)
            // Counts the delimiters ...
            if (u8Data == MODEM_BUFFER_RX_EOL)
            {
                MODEM_BUFFER_RX_Cnt_Eol = MODEM_BUFFER_RX_Cnt_Eol + 1; 
                u8Data = 0; // <EOL>
            }
        #endif
        
        // Adds character to the buffer
    
        MODEM_BUFFER_RX[MODEM_BUFFER_RX_Write_Ptr] = u8Data;
        MODEM_BUFFER_RX_Counter = MODEM_BUFFER_RX_Counter + 1;

        // Adjust the buffer address

        MODEM_BUFFER_RX_Write_Ptr = MODEM_BUFFER_RX_Write_Ptr + 1;
        if (MODEM_BUFFER_RX_Write_Ptr >= MODEM_BUFFER_RX_MAX)  // Ringbuffer
        {
            MODEM_BUFFER_RX_Write_Ptr = 0;
        }
  
        if (MODEM_BUFFER_RX_Write_Ptr == MODEM_BUFFER_RX_Read_Ptr)  // Overflow
        {
            MODEM_BUFFER_RX_Error = MODEM_BUFFER_RX_ERROR_OVERFLOW;
            if (MODEM_BUFFER_RX_Write_Ptr == 0)
            {
                MODEM_BUFFER_RX_Write_Ptr = MODEM_BUFFER_RX_MAX - 1;
            }
            else
            {
                MODEM_BUFFER_RX_Write_Ptr = MODEM_BUFFER_RX_Write_Ptr - 1;
            }
        }    
    } // switch
    
    __enable_irq(); 
    return(u8Data); // Return the added data
}

/**
 ******************************************************************************
 ** \brief Read a single byte from reception-buffer
 **
 ** This function returns a single byte from the reception ring buffer,
 ** and updates status values accordingly
 ** 
 ** \param none
 **
 ** \retval      Received byte
 ** \retval      '0' if no byte is available in buffer
 **
 ******************************************************************************/
uint8_t MODEM_BUFFER_RX_Get_Char(void)
{
    unsigned char ch = 0;
  
    __disable_irq();                              // MODEM_BUFFER_RX_Counter might be modified by RX-IRQ, too
    if (MODEM_BUFFER_RX_Counter > 0)
    {
        // Get a character from the buffer
    
        ch = MODEM_BUFFER_RX[MODEM_BUFFER_RX_Read_Ptr];
        MODEM_BUFFER_RX_Counter = MODEM_BUFFER_RX_Counter - 1;
    
        // Adjust the buffer address

        MODEM_BUFFER_RX_Read_Ptr = MODEM_BUFFER_RX_Read_Ptr + 1;
        if (MODEM_BUFFER_RX_Read_Ptr >= MODEM_BUFFER_RX_MAX)  // Ringbuffer
        {
            MODEM_BUFFER_RX_Read_Ptr = 0;
        }
    }
    
    #if (MODEM_BUFFER_RX_EOL_CNT == 1)
        if (ch == MODEM_BUFFER_RX_EOL)  // End of line, end of command
        {
            MODEM_BUFFER_RX_Cnt_Eol = MODEM_BUFFER_RX_Cnt_Eol - 1;
        }
    #endif
    
    __enable_irq();
    return(ch); 
}

/**
 ******************************************************************************
 ** \brief Returns number of available bytes within reception ring buffer
 **
 ** This function returns the number of characters that are currently available
 ** in the reception ring buffer.
 ** 
 ** \param none
 **
 ** \retval      Number of available bytes
 **
 ******************************************************************************/
uint32_t MODEM_BUFFER_RX_Get_Count_Char()
{
    return(MODEM_BUFFER_RX_Counter);
}

#if (MODEM_BUFFER_RX_EOL_CNT == 1)
    /**
     ******************************************************************************
     ** \brief Returns number of EOL bytes within reception ring buffer
     **
     ** This function returns the number of EOL bytes that are currently available
     ** in the reception ring buffer.
     ** 
     ** \param none
     **
     ** \retval      Number of available EOL bytes
     **
     ******************************************************************************/
    uint32_t MODEM_BUFFER_RX_Get_Count_Eol()
    {
        return(MODEM_BUFFER_RX_Cnt_Eol);
}
#endif

/**
 ******************************************************************************
 ** \brief Return of RX buffer status
 **
 ** This function returns current status of the reception ring buffer
 ** 
 ** \param none
 **
 ** \retval      MODEM_BUFFER_RX_ERROR_NO_ERROR     No error
 ** \retval      MODEM_BUFFER_RX_ERROR_OVERFLOW     Buffer overflow
 **
 ******************************************************************************/
uint8_t MODEM_BUFFER_RX_Get_Error()
{
  return(MODEM_BUFFER_RX_Error);
}

/**
 ******************************************************************************
 ** \brief Clear the RX buffer status
 **
 ** This function clears the RX buffer status
 ** 
 ** \param none
 **
 ** \retval      none
 **
 ******************************************************************************/
void MODEM_BUFFER_RX_Clr_Error()
{
  MODEM_BUFFER_RX_Error = MODEM_BUFFER_RX_ERROR_NO_ERROR;
}

#if (MODEM_BUFFER_RX_EOL_CNT == 1)
/**
 ******************************************************************************
 ** \brief Read one line out of RX buffer
 **
 ** This function returns one line out of the RX buffer. The line end by the given delimiter
 ** 
 ** \param [in]     char    cDelimiter  Line-end indicator
 ** \param [out]    char*   pcOutput    Read line
 **
 ** \retval      none
 **
 ******************************************************************************/
void MODEM_Get_Line(char cDelimiter, char *pcOutput)
{
  unsigned char tmp_cnt = 0;
  unsigned char tmp_ch  = 0;
  
  tmp_ch = MODEM_BUFFER_RX_Get_Char();
  while ((tmp_cnt < (MODEM_BUFFER_RX_LINE-1)) && (tmp_ch != cDelimiter) )
  {
    *pcOutput++ = tmp_ch;
    tmp_cnt = tmp_cnt + 1;
    tmp_ch = MODEM_BUFFER_RX_Get_Char();
  }

  *pcOutput = 0; // terminate string

}
#endif

/**
 ******************************************************************************
 ** \brief Get one received Digi XBee API line out of RX buffer
 **
 ** This function returns one Digi XBee API from the RX buffer.
 ** Ensure that the API identifier 0x7E and two lenght bytes are already received. 
 ** 
 ** \param [out]    char*   pcOutput    Read line
 **
 ** \retval      Length of the read API command line
 **
 ******************************************************************************/
uint16_t MODEM_Get_LineApi(char *pcOutput)
{
    uint8_t u8ApiStart;
    uint16_t u16Apilen;
    //uint8_t u8ApiChecksum;
    uint16_t u16i;
       
    u8ApiStart = MODEM_BUFFER_RX_Get_Char(); 
    if (u8ApiStart != 0x7E)
    {
        #ifdef HMIUART
        sprintf(acPrintfBuffer, "*** Invalid API Frame Start (%02x)", u8ApiStart);
        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
        #endif
    }   

    u16Apilen = MODEM_BUFFER_RX_Get_Char();
    u16Apilen = (u16Apilen << 8) + MODEM_BUFFER_RX_Get_Char();

    while (MODEM_BUFFER_RX_Get_Count_Char() < (u16Apilen + 1)) 
    {
        // wait until all bytes are received
    }

    for (u16i = 0; u16i < u16Apilen; u16i++)
    {
        *pcOutput++ = MODEM_BUFFER_RX_Get_Char();
    }

    //u8ApiChecksum = MODEM_BUFFER_RX_Get_Char();
    MODEM_BUFFER_RX_Get_Char(); // skip checksum byte

    return (u16Apilen);
}

/**
 ******************************************************************************
 ** \brief Return of MODEM state
 **
 ** This function returns the state of the MODEM state machine
 ** 
 ** \param none
 **
 ** \retval      MODEM_STATE_IDLE, ...     See modem.h
 **
 ******************************************************************************/
enModemState_t MODEM_Get_State(void)
{
  return(enModemState);
}  

/**
 ******************************************************************************
 ** \brief Set MODEM state
 **
 ** This function sets the state of the MODEM state machine
 ** 
 ** \param newstate     MODEM_STATE_RESET, ...     See modem.h
 **
 ** \retval none
 **
 ******************************************************************************/
void MODEM_Set_State(enModemState_t newstate)
{
    enModemState = newstate;
}

/**
 ******************************************************************************
 ** \brief Return status of network connection
 **
 ** This function returns the status of network connection
 ** 
 ** \param none
 **
 ** \retval      enModemNbiotConnectState_t MODEM_NBIOT_NOT_CONNECTED or MODEM_NBIOT_CONNECTED
 **
 ******************************************************************************/
enModemNbiotConnectState_t MODEM_Get_NBIOT_Status(void)
{
  return(u32XbeeNbiotConnect);
} 

/*******************************************************************************
*        Digi XBee related Functions
*******************************************************************************/

/**
 ******************************************************************************
 ** \brief Send API AT frame to XBee modem
 **
 ** This function sends a API AT frame to the XBee modem
 ** https://www.digi.com/resources/documentation/Digidocs/90002258/#Reference/r_ap_1.htm
 ** https://www.digi.com/resources/documentation/Digidocs/90002258/#Reference/r_frame_0x08_cell.htm 
 ** 
 ** \param char *cData     Frame Data
 ** \param uint8_t u8Id    Frame ID
 **
 ** \retval none
 **
 ******************************************************************************/
void XBeeSendApiAT(char *cData, uint8_t u8Id)
{
    char acXbeeApiBufferOut[9];
    char *ptr = acXbeeApiBufferOut;
    uint8_t u8Checksum;
    
    *ptr++ = 0x7E;
    *ptr++ = 0x00;  // Length always 0x00 for AT commands
    *ptr++ = 0x04;  // Length always 0x0004 if no value is given
    *ptr++ = 0x08;  // Type: AT command
    u8Checksum = 0x08;
    *ptr++ = u8Id; // Frame ID 
    u8Checksum = u8Checksum + u8Id;
    *ptr++ = cData[0];
    u8Checksum = u8Checksum + cData[0];
    *ptr++ = cData[1];
    u8Checksum = u8Checksum + cData[1];
    u8Checksum = 0xFF - (u8Checksum & 0xFF);
    *ptr++ = u8Checksum;
    Cy_SCB_UART_PutArrayBlocking(Uart_Modem_HW, acXbeeApiBufferOut, 8);
}

/**
 ******************************************************************************
 ** \brief Send API IPv4 frame to XBee modem
 **
 ** This function sends a API AT frame to the XBee modem
 ** https://www.digi.com/resources/documentation/Digidocs/90002258/#Reference/r_ap_1.htm
 ** https://www.digi.com/resources/documentation/Digidocs/90002258/#Reference/r_frame_0x8A_cell.htm
 ** 
 ** \param char *cData     Frame Data
 ** \param uint16_t        API Frame Length
 ** \param uint8_t u8Id    Frame ID
 **
 ** \retval none
 **
 ******************************************************************************/
void XBeeSendApiIpv4(char *cData, uint16_t u16Len, uint8_t u8Id)
{
    char acXbeeApiBufferOut[64];    

    char *ptr = acXbeeApiBufferOut;
    uint8_t u8Checksum;
    uint16_t i;

    // frame
    
    *ptr++ = 0x7E;
    *ptr++ = (u16Len + 12) >> 8;        // Length high-byte (frame-size (11) + payload
    *ptr++ = (u16Len + 12) & 0xFF;      // Length low-byte
    *ptr++ = 0x20;  // Type: IPv4
    *ptr++ = u8Id;  // Frame ID
    *ptr++ = 0xAC;  // << IPv4 address 172.25.102.151
    *ptr++ = 0x19;  // << IPv4 address
    *ptr++ = 0x66;  // << IPv4 address
    *ptr++ = 0x97;  // << IPv4 address
    *ptr++ = 0x07;  // << Port address 1883
    *ptr++ = 0x5B;  // << Port address
    *ptr++ = 0x00;  // Source port adress high-byte
    *ptr++ = 0x00;  // Source port adress low-byte
    *ptr++ = 0x00;  // Protocol UDP=0
    *ptr++ = 0x00;  // Transmit options

    // add payload
    
    for (i=0; i<u16Len; i++)
    {
        *ptr++ = cData[i];
    }
    
    // calculate checksum
    
    u8Checksum = 0;
    for (i=3; i<=(14 + u16Len); i++)
    {
        u8Checksum = u8Checksum + acXbeeApiBufferOut[i];
    }
    u8Checksum = 0xFF - (u8Checksum & 0xFF);
    *ptr++ = u8Checksum;
    
    // Send frame
    
    Cy_SCB_UART_PutArrayBlocking(Uart_Modem_HW, acXbeeApiBufferOut, 16+u16Len);
}

/*******************************************************************************
*        Simple MQTT-SN functions used for access to Telekom Cloud-Of-Things
*        For MQTT/MQTT-SN basics see here: http://mqtt.org/documentation
*        MQTT-SN: http://mqtt.org/new/wp-content/uploads/2009/06/MQTT-SN_spec_v1.2.pdf
*******************************************************************************/

/**
 ******************************************************************************
 ** \brief Send a MQTT-SN CONNECT command
 **
 ** This function prepares a CONNECT type MQTT-SN message.
 ** The message is send directly to XBee modem by IPv4 command type
 ** 
 ** \param uint8_t flagfield    e.g. MQTTSN_CLEANSESSION
 ** \param uint16_t duration    Max time in seconds to keep connection
 ** \param uint8_t packetid     Frame ID (needed later for XBee API frame ID)
 **
 ** \retval none
 **
 ******************************************************************************/
void MQTTSN_Connect(uint8_t flagfield, uint16_t duration, uint8_t packetid)
{
    char acMqttsnPackage[31];
    sprintf(acMqttsnPackage, "%c%c%c%c%c%c%s",0x1D, 0x04, flagfield, 0x01, (duration>>8), (duration&0xff), AUTH_IMSI""AUTH_PWD);

    #ifdef HMIUART
    //    Cy_SCB_UART_PutString(Uart_HMI_HW, "\rMQTTSN-CONNECT  = ");
    //    Cy_SCB_UART_PutArrayBlocking(Uart_HMI_HW, acMqttsnPackage, 29); 
    #endif

    XBeeSendApiIpv4(acMqttsnPackage, 29, packetid); 
}

/**
 ******************************************************************************
 ** \brief Send a MQTT-SN REGISTER command
 **
 ** This function prepares a REGISTER type MQTT-SN message.
 ** The message is send directly to XBee modem by IPv4 command type
 ** The topics are pre-defined in file <_user_config_.h>
 ** 
 ** \param char *topicname      Specified by Cloud provider, e.g. "NBIoT/"AUTH_IMSI"/MES/1"
 ** \param uint8_t packetid     Frame ID (needed later for XBee API frame ID)
 **
 ** \retval none
 **
 ******************************************************************************/
void MQTTSN_Register(char *topicname, uint8_t packetid)
{
    char acMqttsnPackage[64];
    sprintf(acMqttsnPackage, "%c%c%c%c%c%c%s",6+strlen(topicname), 0x0A, 0x00, 0x00, 0x00, packetid, topicname);
    
    #ifdef HMIUART
    //Cy_SCB_UART_PutString(Uart_HMI_HW, "\rMQTTSN-REGISTER = ");
    //Cy_SCB_UART_PutArrayBlocking(Uart_HMI_HW, acMqttsnPackage, 6+strlen(topicname));
    #endif
    
    XBeeSendApiIpv4(acMqttsnPackage, 6+strlen(topicname), packetid);
}

/**
 ******************************************************************************
 ** \brief Send a MQTT-SN PUBLISH command
 **
 ** This function prepares a PUBLISH type MQTT-SN message.
 ** The message is send directly to XBee modem by IPv4 command type
 ** 
 ** \param uint16_t u16TopicId  The ID was received while registering the topic
 ** \param uint16_t u16Value    The data payload
 ** \param uint8_t packetid     Frame ID (needed later for XBee API frame ID)
 **
 ** \retval none
 **
 ******************************************************************************/
void MQTTSN_Publish(uint16_t u16TopicId, uint16_t u16Value, uint8_t packetid)
{
    char acValue[6]; // u16 string array
    uint8_t len;
    
    char acMqttsnPackage[16];
    
    len = sprintf(acValue, "%d", u16Value); // Convert value to a string (as requested by CoT)
    
    sprintf(acMqttsnPackage, "%c%c%c%c%c%c%c%s", 7+len, 0x0C, 0x00, (u16TopicId>>8), (u16TopicId&0xff), 0x00, packetid, acValue);
    
    #ifdef HMIUART
    //Cy_SCB_UART_PutString(Uart_HMI_HW, "\rMQTTSN-PUBLISH  = ");
    //Cy_SCB_UART_PutArrayBlocking(Uart_HMI_HW, acMqttsnPackage, 9);
    #endif
    
    XBeeSendApiIpv4(acMqttsnPackage, 7+len, packetid);
}

/**
 ******************************************************************************
 ** \brief Send a MQTT-SN DISCONNECT command
 **
 ** This function prepares a DISCONNECT type MQTT-SN message.
 ** The message is send directly to XBee modem by IPv4 command type
 ** 
 ** \param uint8_t packetid     Frame ID (needed later for XBee API frame ID)
 **
 ** \retval none
 **
 ******************************************************************************/
void MQTTSN_Disconnect(uint8_t packetid)
{
    char acMqttsnPackage[2] = { 0x02, 0x18 };
    
    #ifdef HMIUART
    Cy_SCB_UART_PutString(Uart_HMI_HW, "\rMQTTSN-DISCONN  = ");
    Cy_SCB_UART_PutArrayBlocking(Uart_HMI_HW, acMqttsnPackage, 2);
   #endif
        
    XBeeSendApiIpv4(acMqttsnPackage, 2, packetid);
}

/**
 ******************************************************************************
 ** \brief Evaluation of received API frame
 **
 ** This function evaluates a incoming API frame.
 ** Corresponding global variables are set accordingly to to teh message type.
 ** 
 ** \param char *frame          Received API frame
 ** \param uint16_t u16len      API frame length
 **
 ** \retval uint32_t            0:Successful 1:Error
 **
 ******************************************************************************/
uint32_t XBeeEvaluateApi(char *frame, uint16_t u16len)
{
    uint32_t u32Result = 0xff; // uninitilized error
    uint8_t i;
    
    #ifdef HMIUART
    //Cy_SCB_UART_PutArrayBlocking(Uart_HMI_HW, frame, u16len); // debug output
    #endif
    
    switch (frame[0])
    {
        case 0x8A : //Modem Status https://www.digi.com/resources/documentation/Digidocs/90002258/#Reference/r_frame_0x8A_cell.htm
        
            u32XbeeModemStatus = frame[1];
            
            if (0x03 == u32XbeeModemStatus) // 3 = Unregistered with cellular network
            {
                #ifdef HMIUART  
                //Cy_SCB_UART_PutString(Uart_HMI_HW, "\rModem Status changed -> Disconnect from network");
                #endif
                Cy_GPIO_Write(LED_Blue_PORT, LED_Blue_NUM, LED_ON);     // LED Blue  on
                Cy_GPIO_Write(LED_Green_PORT, LED_Green_NUM, LED_OFF);  // LED Green off
                enModemState = MODEM_XBEE_AI;                           // Wait until connection is done
            }
            else
            {
                if (0x02 == u32XbeeModemStatus) // 2 = Registered with cellular network 
                {
                    #ifdef HMIUART  
                    //Cy_SCB_UART_PutString(Uart_HMI_HW, "\rModem Status changed -> Connected to network");
                    #endif
                    enModemState = MODEM_STATE_MQTT_CONNECT;            // automatical reconnect to Cloud
                }                
            }
            u32Result = 0;
            break;
        
        case 0x88 : // AT command response frame https://www.digi.com/resources/documentation/Digidocs/90002258/#Reference/r_frame_0x88_cell.htm
        
                #ifdef HMIUART  
                //Cy_SCB_UART_PutString(Uart_HMI_HW, "\rAT Response -> ");
                #endif
                
                if (0 == frame[4]) // verify frame status
                {
                
                    // AI command response?
                    if (0 == strncmp(&frame[2], "AI", 2))
                    {
                        u32XbeeResponseAi = frame[5];
                        u32Result = 0;
                    }
                    else    
                    // TP command response?
                    if (0 == strncmp(&frame[2], "TP", 2))
                    {
                        #ifdef HMIUART
                        sprintf(acPrintfBuffer, "Temp = %d", (uint16_t)(frame[5] << 8) + frame[6]);
                        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                        #endif
                        
                        u32Result = 0;
                    }
                    else
                    {
                        #ifdef HMIUART
                        sprintf(acPrintfBuffer, "Command not supported (%c%c)", frame[2], frame[3]);
                        Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer); 
                        #endif
                        u32Result = 1;
                    }
                
                }
                else
                {
                    #ifdef HMIUART
                    sprintf(acPrintfBuffer, "Frame Status Error (%d)", frame[4]);
                    Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                    #endif
                    u32Result = 1;
                }
                break;

        case 0x89 : // Transmit (TX) Status https://www.digi.com/resources/documentation/Digidocs/90002258/#Reference/r_frame_0x89_cell.htm
             
            u32XbeeTransmitStatus = frame[2];
            if (0 == u32XbeeTransmitStatus)
            {
                u32Result = 0;
            }
            else
            {
                #ifdef HMIUART
                sprintf(acPrintfBuffer, "Transmit Status Error (%x)", (unsigned int)u32XbeeTransmitStatus);
                Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                #endif
                u32Result = 1;
            }
            break;
                

        case 0xB0 : // Receive (RX) Packet: IPv4 https://www.digi.com/resources/documentation/Digidocs/90002258/#Reference/r_frame_0xB0.htm

            if (u16len > 12)
            {
                for (i = 0; i < frame[11]; i++)
                {
                    acMqttsnBufferIn[i] = frame[11+i];  // Extract MQTT-SN package
                    u32Result = 0;
                }
                
                // CONNACK?
                if ( (acMqttsnBufferIn[0] == 0x03) && (acMqttsnBufferIn[1] == 0x05) && (acMqttsnBufferIn[2] == 0x00) )
                {
                    u32XbeeNbiotConnect = 1;
                }
                
                //DISCONNECT?
                if ( (acMqttsnBufferIn[0] == 0x02) && (acMqttsnBufferIn[1] == 0x18) )
                {
                    u32XbeeNbiotConnect = 0;
                    Cy_GPIO_Write(LED_Blue_PORT, LED_Blue_NUM, LED_ON);     // LED Blue  on
                    Cy_GPIO_Write(LED_Green_PORT, LED_Green_NUM, LED_OFF);  // LED Green off
                    #ifdef HMIUART
                    Cy_SCB_UART_PutString(Uart_HMI_HW, "\r*** MQTT-SN Disconnect received");
                    #endif
                    enModemState = MODEM_XBEE_AI; // Automatically reconnect
                }
                
                // REGACK
                if ( (acMqttsnBufferIn[0] == 0x07) && (acMqttsnBufferIn[1] == 0x0B) )
                {
                    u16TopicId = (acMqttsnBufferIn[2] << 8) + acMqttsnBufferIn[3];
                }
            }
            else
            {
                #ifdef HMIUART
                Cy_SCB_UART_PutString(Uart_HMI_HW, "\r*** Unknown Receive (RX) Packet: IPv4");
                #endif
                u32Result = 1;   
            }
            break;
                
        default: // currently unsupported frame types
           
            #ifdef HMIUART
            sprintf(acPrintfBuffer, "Unsupported Frame Type (%x)", frame[0]);
            Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
            #endif
            u32Result = 1;
    }

    return(u32Result);
}

/**
 ******************************************************************************
 ** \brief State machine for handling the modem
 **
 ** This function handles the message flow from and to the modem.
 ** (Re-)Connect and Registering is done automatically.
 ** 
 ** \pre This function needs to be called frequently by main application
 ** 
 ** \retval none
 **
 ******************************************************************************/
void XBEE_EventHandler (void)
{
    uint16_t u16ApiLen;
    
    if ( MODEM_BUFFER_RX_Get_Count_Char() > 3)              // Check incoming data
    {
        u16ApiLen = MODEM_Get_LineApi(acXbeeApiBufferIn);   // read the frame data, and get frame length
        XBeeEvaluateApi(acXbeeApiBufferIn, u16ApiLen);      // evaluate frame
    }
    
    if (u32ModemTimeout)
    {
        u32ModemTimeout = u32ModemTimeout - 1;
    }
    
    switch (enModemState)
    {
        case MODEM_STATE_IDLE: // Nothing to do 
            
            break;
        
        // AI - check network connection
        
        case MODEM_XBEE_AI:
        
            u32XbeeResponseAi = 0xAA; // invalidate answer
            #ifdef HMIUART
            Cy_SCB_UART_PutString(Uart_HMI_HW, "\rPC ->: AI");
            #endif
            XBeeSendApiAT("AI", 1);
            enModemState = MODEM_XBEE_AI_WAIT;
            CyDelay(100);
            break;

        case MODEM_XBEE_AI_WAIT:
            
            if (u32XbeeResponseAi != 0xaa)
            {
                #ifdef HMIUART
                sprintf(acPrintfBuffer, " -> Modem: %02x", (unsigned int)u32XbeeResponseAi);
                Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                #endif
 
                if (u32XbeeResponseAi == 0)
                {
                    #ifdef HMIUART
                    Cy_SCB_UART_PutString(Uart_HMI_HW, "\r*** Modem Connected to network");
                    #endif
                    enModemState = MODEM_STATE_MQTT_CONNECT;
                }
                else
                {
                    u32ModemTimeout = 100; // 10sec
                    enModemState = MODEM_XBEE_AI_DELAY;
                }
            }
            break;

        case MODEM_XBEE_AI_DELAY:
            
            if (0 == u32ModemTimeout)
            {
                enModemState = MODEM_XBEE_AI; // issue new AI command
            }
            break;
            
        // MQTT-SN CONNECT
        
        case MODEM_STATE_MQTT_CONNECT:
            
            u32ModemTimeout = 300; // 30sec
            #ifdef HMIUART
            Cy_SCB_UART_PutString(Uart_HMI_HW, "\rPC ->: MQTT-SN Connect");
            #endif
            MQTTSN_Connect(MQTTSN_CLEANSESSION, 900, 1);
            enModemState = MODEM_STATE_MQTT_CONNECT_WAIT;
            break;
            
        case MODEM_STATE_MQTT_CONNECT_WAIT:
            
            if (0 == u32ModemTimeout)
            {
                enModemState = MODEM_STATE_MQTT_CONNECT;   
            }
            if(u32XbeeNbiotConnect == 1)
            {
                #ifdef HMIUART
                 Cy_SCB_UART_PutString(Uart_HMI_HW, "  -> Done!");
                #endif
                enModemState = MODEM_STATE_MQTT_REGISTER1;  
            }
            break;

        // MQTT-SN REGISTER
            
        case MODEM_STATE_MQTT_REGISTER1:
        
            #ifdef HMIUART
            Cy_SCB_UART_PutString(Uart_HMI_HW, "\rPC ->: MQTT-SN Register Topic 1");
            #endif
            u32ModemTimeout = 300; // 30sec
            u16TopicId = 0; // clear value
            MQTTSN_Register(TOPIC1, 2);
            enModemState = MODEM_STATE_MQTT_REGISTER1_WAIT; 
            break;
            
        case MODEM_STATE_MQTT_REGISTER1_WAIT:

            if (0 == u32ModemTimeout)
            {
                enModemState = MODEM_STATE_MQTT_REGISTER1;   
            }
            if (u16TopicId != 0)
            {
                u16TopicId1 = u16TopicId;  // Save received ID
                #ifdef HMIUART
                sprintf(acPrintfBuffer, " -> Done! (Topic 1 ID = 0x%04X)", u16TopicId1);
                Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                #endif
                enModemState = MODEM_STATE_MQTT_REGISTER2;
            }
            break;
            
        case MODEM_STATE_MQTT_REGISTER2:
        
            #ifdef HMIUART
            Cy_SCB_UART_PutString(Uart_HMI_HW, "\rPC ->: MQTT-SN Register Topic 2");
            #endif
            u32ModemTimeout = 300; // 30sec
            u16TopicId = 0; // clear value
            MQTTSN_Register(TOPIC2, 3);
            enModemState = MODEM_STATE_MQTT_REGISTER2_WAIT; 
            break;
            
        case MODEM_STATE_MQTT_REGISTER2_WAIT:

            if (0 == u32ModemTimeout)
            {
                enModemState = MODEM_STATE_MQTT_REGISTER2;   
            }
            if (u16TopicId != 0)
            {
                u16TopicId2 = u16TopicId;  // Save received ID
                #ifdef HMIUART
                sprintf(acPrintfBuffer, " -> Done! (Topic 2 ID = 0x%04X)", u16TopicId2);
                Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                #endif
                enModemState = MODEM_STATE_MQTT_REGISTER3;
            }
            break;
            
        case MODEM_STATE_MQTT_REGISTER3:
        
            #ifdef HMIUART
            Cy_SCB_UART_PutString(Uart_HMI_HW, "\rPC ->: MQTT-SN Register Topic 3");
            #endif
            u32ModemTimeout = 300; // 30sec
            u16TopicId = 0; // clear value
            MQTTSN_Register(TOPIC3, 4);
            enModemState = MODEM_STATE_MQTT_REGISTER3_WAIT; 
            break;
            
        case MODEM_STATE_MQTT_REGISTER3_WAIT:

            if (0 == u32ModemTimeout)
            {
                enModemState = MODEM_STATE_MQTT_REGISTER3;   
            }
            if (u16TopicId != 0)
            {
                u16TopicId3 = u16TopicId;  // Save received ID
                #ifdef HMIUART
                sprintf(acPrintfBuffer, " -> Done! (Topic 3 ID = 0x%04X)", u16TopicId3);
                Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                #endif
                enModemState = MODEM_STATE_MQTT_REGISTER4;
            }
            break;
            
        case MODEM_STATE_MQTT_REGISTER4:
        
            #ifdef HMIUART
            Cy_SCB_UART_PutString(Uart_HMI_HW, "\rPC ->: MQTT-SN Register Topic 4");
            #endif
            u32ModemTimeout = 300; // 30sec
            u16TopicId = 0; // clear value
            MQTTSN_Register(TOPIC4, 5);
            enModemState = MODEM_STATE_MQTT_REGISTER4_WAIT; 
            break;
            
        case MODEM_STATE_MQTT_REGISTER4_WAIT:

            if (0 == u32ModemTimeout)
            {
                enModemState = MODEM_STATE_MQTT_REGISTER4;   
            }
            if (u16TopicId != 0)
            {
                u16TopicId4 = u16TopicId;  // Save received ID
                #ifdef HMIUART
                sprintf(acPrintfBuffer, " -> Done! (Topic 4 ID = 0x%04X)", u16TopicId4);
                Cy_SCB_UART_PutString(Uart_HMI_HW, acPrintfBuffer);
                #endif
                Cy_GPIO_Write(LED_Blue_PORT, LED_Blue_NUM, LED_OFF);    // LED Blue  off
                Cy_GPIO_Write(LED_Green_PORT, LED_Green_NUM, LED_ON);   // LED Green on
                enModemState = MODEM_STATE_PUBLISHING;
            }
            break;
            
        case MODEM_STATE_PUBLISHING:
            
            // Publish is done within main.c
            break;
            
                    
        default : // should never come here
                
            #ifdef HMIUART
            Cy_SCB_UART_PutString(Uart_HMI_HW, "*** FATAL ERROR - never come here");
            #endif
            enModemState = MODEM_STATE_IDLE;
            break;
    } // switch (enModemState)
}

/* [] END OF FILE */

